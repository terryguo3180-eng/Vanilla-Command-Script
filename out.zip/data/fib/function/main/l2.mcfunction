scoreboard players operation i main = i main
scoreboard players add i main 1
return run function fib:main/l0