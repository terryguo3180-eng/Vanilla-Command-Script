scoreboard players set result main 0
scoreboard players set i main 1
return run function fib:main/l0