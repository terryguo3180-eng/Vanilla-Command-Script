scoreboard players set result main 0
scoreboard players set n fib 20
execute store result score #t0 main run function fib:fib/_
scoreboard players operation result main = #t0 main
return run scoreboard players get result main