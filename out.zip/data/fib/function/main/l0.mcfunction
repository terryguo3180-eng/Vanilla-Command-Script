execute store result score #t0 main if score i main matches ..25
execute unless score #t0 main matches 0 run return run function fib:main/l1
return run function fib:main/l3