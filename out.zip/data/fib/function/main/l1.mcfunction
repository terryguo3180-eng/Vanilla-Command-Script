scoreboard players operation n fib = i main
scoreboard players set m fib 0
execute store result score #t1 main run function fib:fib/_
scoreboard players operation result main = #t1 main
tellraw @a {"score":{"name":"result","objective":"main"}}
return run function fib:main/l2