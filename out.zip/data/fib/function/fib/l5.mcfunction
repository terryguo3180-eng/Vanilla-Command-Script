scoreboard players operation n fib = n fib
scoreboard players operation n fib -= m fib
return run function fib:fib/l4