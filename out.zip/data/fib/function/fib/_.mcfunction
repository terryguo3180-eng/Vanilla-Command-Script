execute store result score #t2 fib if score m fib matches 1..
execute unless score #t2 fib matches 0 run return run function fib:fib/l5
return run function fib:fib/l4