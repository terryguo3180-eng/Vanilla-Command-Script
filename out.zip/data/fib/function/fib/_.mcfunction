execute store result score #t1 fib if score n fib matches 1
execute store result score #t2 fib if score n fib matches 2
execute store result score #t3 fib unless score #t1 fib matches 0
execute unless score #t2 fib matches 0 run scoreboard players set #t3 fib 1
execute unless score #t3 fib matches 0 run return run function fib:fib/l1
return run function fib:fib/l0