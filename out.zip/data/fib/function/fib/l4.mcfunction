execute store result score #t3 fib if score n fib matches 1
execute store result score #t4 fib if score n fib matches 2
execute store result score #t5 fib unless score #t3 fib matches 0
execute unless score #t4 fib matches 0 run scoreboard players set #t5 fib 1
execute unless score #t5 fib matches 0 run return run function fib:fib/l7
return run function fib:fib/l6