scoreboard players operation #t4 fib = n fib
scoreboard players remove #t4 fib 1
data modify storage fib frames append value {}
execute store result storage fib frames[-1].v0 int 1 run scoreboard players get n fib
execute store result storage fib frames[-1].v1 int 1 run scoreboard players get #t1 fib
execute store result storage fib frames[-1].v2 int 1 run scoreboard players get #t2 fib
execute store result storage fib frames[-1].v3 int 1 run scoreboard players get #t3 fib
execute store result storage fib frames[-1].v4 int 1 run scoreboard players get #t4 fib
scoreboard players operation n fib = #t4 fib
execute store result score #t5 fib run function fib:fib/_
execute store result score n fib run data get storage fib frames[-1].v0
execute store result score #t1 fib run data get storage fib frames[-1].v1
execute store result score #t2 fib run data get storage fib frames[-1].v2
execute store result score #t3 fib run data get storage fib frames[-1].v3
execute store result score #t4 fib run data get storage fib frames[-1].v4
data remove storage fib frames[-1]
scoreboard players operation #t6 fib = n fib
scoreboard players remove #t6 fib 2
data modify storage fib frames append value {}
execute store result storage fib frames[-1].v0 int 1 run scoreboard players get n fib
execute store result storage fib frames[-1].v1 int 1 run scoreboard players get #t1 fib
execute store result storage fib frames[-1].v2 int 1 run scoreboard players get #t2 fib
execute store result storage fib frames[-1].v3 int 1 run scoreboard players get #t3 fib
execute store result storage fib frames[-1].v4 int 1 run scoreboard players get #t4 fib
execute store result storage fib frames[-1].v5 int 1 run scoreboard players get #t5 fib
execute store result storage fib frames[-1].v6 int 1 run scoreboard players get #t6 fib
scoreboard players operation n fib = #t6 fib
execute store result score #t7 fib run function fib:fib/_
execute store result score n fib run data get storage fib frames[-1].v0
execute store result score #t1 fib run data get storage fib frames[-1].v1
execute store result score #t2 fib run data get storage fib frames[-1].v2
execute store result score #t3 fib run data get storage fib frames[-1].v3
execute store result score #t4 fib run data get storage fib frames[-1].v4
execute store result score #t5 fib run data get storage fib frames[-1].v5
execute store result score #t6 fib run data get storage fib frames[-1].v6
data remove storage fib frames[-1]
scoreboard players operation #t8 fib = #t5 fib
scoreboard players operation #t8 fib += #t7 fib
return run scoreboard players get #t8 fib