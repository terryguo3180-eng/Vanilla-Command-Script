scoreboard objectives add fib dummy
scoreboard objectives add main dummy