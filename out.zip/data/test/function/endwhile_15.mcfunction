# 如果是质数，则计数
execute if score is_prime test matches 0 run return run function test:endif_19
scoreboard players add count test 1
function test:endif_19