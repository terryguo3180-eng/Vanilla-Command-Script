scoreboard players add candidate test 1
function test:continue_6