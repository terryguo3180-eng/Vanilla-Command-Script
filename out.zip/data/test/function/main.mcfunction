scoreboard objectives add test dummy
scoreboard players set limit test 100
scoreboard players set count test 0
scoreboard players set candidate test 2
execute store result score t0 test if score candidate test <= limit test
function test:while_6