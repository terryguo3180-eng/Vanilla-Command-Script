execute store result score t4 test if score candidate test <= limit test
execute if score t4 test matches 1 run return run function test:while_6
function test:endwhile_21