execute if score t1 test matches 0 run return run function test:endwhile_15
scoreboard players operation t1 test = candidate test
scoreboard players operation t1 test %= divisor test
execute store result score t2 test if score t1 test matches 0
execute if score t2 test matches 0 run return run function test:endif_14
scoreboard players set is_prime test 0
return run function test:endwhile_15
function test:endif_14