scoreboard players operation t2 test = divisor test
scoreboard players operation t2 test *= divisor test
execute store result score t3 test if score t2 test <= candidate test
execute if score t3 test matches 1 run return run function test:while_11
function test:endwhile_15