execute if score t0 test matches 0 run return run function test:endwhile_21
scoreboard players set is_prime test 1
scoreboard players set divisor test 2
# 检查是否能被除数整除
scoreboard players operation t0 test = divisor test
scoreboard players operation t0 test *= divisor test
execute store result score t1 test if score t0 test <= candidate test
function test:while_11